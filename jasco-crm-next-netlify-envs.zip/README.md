# JASCO CRM — Next.js API (Multi-tenant)

Production-ready scaffold for a multi-company CRM backend + minimal UI shell.

## Stack
- **Next.js 14 (App Router)** — API routes under `/api/*`
- **PostgreSQL + Prisma** — Multi-tenant via `companyId` on all tables
- **Auth** — Email+password with session tokens (simple), session table
- **RBAC** — SUPER_ADMIN, COMPANY_ADMIN, BRANCH_MANAGER, SALES_REP
- **Jobs** — BullMQ on Redis (queue wiring point provided)
- **Email** — Resend or SMTP (MailHog for local)
- **Realtime** — Socket.IO (server bootstrap point at `src/lib/realtime.ts`)

## Quick Start
1. Start infra:
   ```bash
   docker-compose up -d
   ```
2. Copy env and edit as needed:
   ```bash
   cp .env.example .env
   ```
3. Install deps:
   ```bash
   npm i
   ```
4. Generate Prisma client & migrate:
   ```bash
   npm run prisma:generate
   npm run prisma:migrate
   ```
5. Seed demo data:
   ```bash
   npm run seed
   ```
6. Run dev server:
   ```bash
   npm run dev
   ```

Open http://localhost:3000

### Log in
`POST /api/auth/login` with JSON:
```json
{ "email": "sysadmin@jasco.local", "password": "admin123" }
```
Use returned `token` in header for subsequent calls:
```
Authorization: Bearer <token>
X-Company-Id: <companyId>
```

### Example calls
- `GET /api/tenants`
- `POST /api/branches` `{ "name": "STEELS - Abha", "companyId": "<id>" }`
- `GET /api/leads?companyId=<id>`
- `POST /api/leads` lead payload including `companyId`, `branchId`, `productGroupId`

## Notes on Multi-tenancy
- Every domain object has a `companyId`. RBAC helpers ensure users can access only their scope.
- For hard isolation at DB level you could move to **schema-per-tenant**; this scaffold opts for **row-based isolation** with code enforcement.

## Email
- Local dev uses MailHog (open http://localhost:8025). For production set `RESEND_API_KEY` or SMTP credentials.

## Realtime notifications
- Integrate `getIO(server)` in `next/server` custom server (or use a separate Node process). Emit events for new leads/tasks.

## Hardening for Production
- Replace simple session with NextAuth/JWT or session cookies.
- Add rate limiting (e.g., `@upstash/ratelimit`) and input validation (Zod already included).
- Add audit logs table (userId, action, entity, timestamp).
- Set CORS properly if calling API from a different domain.


## 🚀 One-command production deploy (Docker + Traefik + auto-SSL)
Prereqs: A Linux VM with Docker + Docker Compose, a DNS A-record pointing your domain to the VM IP.

1) Copy env:
```bash
cp .env.production.example .env.production
# edit .env.production -> set DOMAIN and ACME_EMAIL and NEXTAUTH_SECRET
```

2) Build and run:
```bash
docker compose -f docker-compose.prod.yml --env-file .env.production up -d --build
```
- Traefik terminates TLS with Let's Encrypt.
- App is available at: `https://$DOMAIN`

### Using Nginx instead of Traefik (no auto-SSL)
- Provided `nginx/` folder with a basic reverse-proxy. You can pair it with `certbot` manually if preferred.


## 🌐 Deploy on Netlify (Next.js App Router + Serverless)
Netlify auto-builds and deploys the Next.js app using the Next Runtime plugin.

### Steps
1. Push this repo to GitHub/GitLab/Bitbucket.
2. In Netlify → **Add new site** → **Import from Git**, pick the repo.
3. Set build command: `npm run build` (default).
4. Set **Environment variables** (Site settings → Build & deploy → Environment):
   - `NEXTAUTH_URL` = `https://<your-netlify-site>.netlify.app` *(or custom domain)*
   - `NEXTAUTH_SECRET` = strong random string
   - `DATABASE_URL` = (e.g., Neon/Render/Cloud SQL Postgres connection URL)
   - `REDIS_URL` = (e.g., Upstash Redis URL)
   - `RESEND_API_KEY` or SMTP creds (`SMTP_HOST`, `SMTP_PORT`, `SMTP_USER`, `SMTP_PASS`)
   - `EMAIL_FROM` = `crm@your-domain`
5. Click **Deploy**.

> Netlify provides HTTPS automatically for your Netlify subdomain and custom domains.

### Prisma on Netlify Functions
- Functions are bundled with `@prisma/client`. The `netlify.toml` includes `included_files` for Prisma engine files.
- Use a **serverless-friendly** Postgres (Neon recommended).
- Run migrations out-of-band during CI/CD or via manual `npx prisma migrate deploy` (e.g., GitHub Action)

### Recommended managed services
- **Postgres**: Neon (serverless, free tier) → use pooled connection string
- **Redis**: Upstash Redis → copy REST URL or `redis://` URL
- **Email**: Resend (preferred) or any SMTP provider

### Local testing with Netlify CLI
```bash
npm i -g netlify-cli
netlify dev
```
This runs Next.js with the Netlify runtime locally.

### Notes
- Background jobs: run BullMQ workers off-platform (e.g., a small VM) or replace with Netlify Scheduled Functions for periodic tasks.
- Realtime (Socket.IO): Prefer a separate small Node/WS server (e.g., Fly.io/Render) or switch to Pusher/Ably for fully managed websockets. Your API stays on Netlify.


## 🧪 Staging & 🚀 Production Environments (Netlify + GitHub Actions)

### Branch strategy
- **main** → Production
- **staging** → Staging (Netlify branch deploy)

### Netlify setup
Create two environments in Netlify UI:
- **Production** (linked to `main`): add env vars for PROD (same keys as .env.production.example).
- **Staging** (linked to branch deploys / `staging`): add env vars for STAGING (same keys as .env.staging.example).

> Netlify automatically provisions HTTPS for both your production domain and staging subdomains.

### GitHub Secrets
Repo → Settings → Secrets and variables → Actions:
- `PROD_DATABASE_URL`, `PROD_NETLIFY_BUILD_HOOK`
- `STAGING_DATABASE_URL`, `STAGING_NETLIFY_BUILD_HOOK`

### Pipelines
- On push to `main` → **Production** workflow runs `prisma migrate deploy` against PROD DB, then triggers Netlify PROD build.
- On push to `staging` → **Staging** workflow runs `prisma migrate deploy` against STAGING DB, then triggers Netlify STAGING build.

### Rollback safety
- Use **Neon branching** to snapshot/restore database quickly.
- You can disable the workflows from GitHub if you need to pause auto-deploys.
