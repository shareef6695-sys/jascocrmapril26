// Example edge function (optional). Enable in netlify.toml 'edge_functions' section.
// File: netlify/edge-functions/edge-realtime.ts
export default async (request: Request) => {
  return new Response(JSON.stringify({ ok: true, path: new URL(request.url).pathname }), {
    headers: { "content-type": "application/json" }
  });
};
