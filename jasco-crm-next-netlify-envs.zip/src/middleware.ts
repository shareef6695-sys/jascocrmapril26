import { NextResponse } from "next/server";
import type { NextRequest } from "next/server";

export function middleware(req: NextRequest) {
  // Example auth gate for /api protected routes (except /api/auth/*)
  const { pathname } = req.nextUrl;
  if (pathname.startsWith("/api") && !pathname.startsWith("/api/auth")) {
    // Require an Authorization: Bearer <token> header (very simple demo token check)
    const auth = req.headers.get("authorization");
    if (!auth) return new NextResponse(JSON.stringify({ error: "Unauthorized" }), { status: 401 });
  }
  return NextResponse.next();
}

export const config = { matcher: ["/api/:path*"] };
