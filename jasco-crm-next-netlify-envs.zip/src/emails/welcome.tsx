import * as React from "react";
import { Html, Body, Container, Heading, Text } from "@react-email/components";

export default function WelcomeEmail({ name }: { name: string }) {
  return (
    <Html>
      <Body style={{ background: '#f6f9fc' }}>
        <Container style={{ background: '#fff', padding: 20 }}>
          <Heading>Welcome to JASCO CRM</Heading>
          <Text>Hello {name}, your account has been created successfully.</Text>
        </Container>
      </Body>
    </Html>
  );
}
