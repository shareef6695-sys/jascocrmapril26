export default function Home() {
  return <main style={{padding: 24}}><h1>JASCO CRM API (Next.js)</h1><p>Use /api/auth/login, then include <code>Authorization: Bearer &lt;token&gt;</code> header.</p></main>;
}
