import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import { withAuth } from "@/lib/handler";
import { assert, canManageAdminCenter } from "@/lib/rbac";

export async function GET(req: NextRequest) {
  // Public list for demo (limit fields)
  const companies = await prisma.company.findMany({ select: { id: true, code: true, name: true } });
  return NextResponse.json(companies);
}

export async function POST(req: NextRequest) {
  return withAuth(req, async ({ req, user }) => {
    assert(user.role === "SUPER_ADMIN", "Only Super Admin can create companies");
    const { code, name } = await req.json();
    const c = await prisma.company.create({ data: { code, name } });
    return NextResponse.json(c);
  });
}
