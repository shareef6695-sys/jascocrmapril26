import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import { withAuth } from "@/lib/handler";
import { assert, canViewCompany, canManageAdminCenter } from "@/lib/rbac";

export async function GET(req: NextRequest) {
  return withAuth(req, async ({ req, user }) => {
    const companyId = req.nextUrl.searchParams.get("companyId");
    assert(companyId && canViewCompany(user, companyId), "Forbidden");
    const rows = await prisma.branch.findMany({ where: { companyId } });
    return NextResponse.json(rows);
  });
}

export async function POST(req: NextRequest) {
  return withAuth(req, async ({ req, user }) => {
    const { name, companyId } = await req.json();
    assert(canManageAdminCenter(user) && (user.role==="SUPER_ADMIN" || user.companyId===companyId), "Forbidden");
    const row = await prisma.branch.create({ data: { name, companyId } });
    return NextResponse.json(row);
  });
}
