import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import { withAuth } from "@/lib/handler";
import { assert, canViewCompany } from "@/lib/rbac";

export async function GET(req: NextRequest) {
  return withAuth(req, async ({ req, user }) => {
    const companyId = req.nextUrl.searchParams.get("companyId");
    assert(companyId && canViewCompany(user, companyId), "Forbidden");
    const rows = await prisma.target.findMany({ where: { companyId } });
    return NextResponse.json(rows);
  });
}

export async function POST(req: NextRequest) {
  return withAuth(req, async ({ req, user }) => {
    const body = await req.json();
    assert(canViewCompany(user, body.companyId), "Forbidden");
    const row = await prisma.target.create({ data: body });
    return NextResponse.json(row);
  });
}
