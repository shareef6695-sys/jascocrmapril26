import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/db";

export async function POST(req: NextRequest) {
  const auth = req.headers.get("authorization") || "";
  const token = auth.replace("Bearer ", "");
  if (!token) return NextResponse.json({ ok: true });
  await prisma.session.deleteMany({ where: { token } });
  return NextResponse.json({ ok: true });
}
