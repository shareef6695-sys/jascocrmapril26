import NextAuth from "next-auth";
import { PrismaAdapter } from "@next-auth/prisma-adapter";
import { prisma } from "@/lib/db";
import Google from "next-auth/providers/google";
import AzureAD from "next-auth/providers/azure-ad";

const handler = NextAuth({
  adapter: PrismaAdapter(prisma),
  session: { strategy: "database" },
  providers: [
    Google({
      clientId: process.env.GOOGLE_CLIENT_ID!,
      clientSecret: process.env.GOOGLE_CLIENT_SECRET!,
    }),
    AzureAD({
      clientId: process.env.AZURE_AD_CLIENT_ID!,
      clientSecret: process.env.AZURE_AD_CLIENT_SECRET!,
      tenantId: process.env.AZURE_AD_TENANT_ID!,
    }),
  ],
  callbacks: {
    async session({ session, user }) {
      // Attach companyId/branchId if present on User
      if (session.user) {
        (session.user as any).id = user.id;
        (session.user as any).companyId = (user as any).companyId ?? null;
        (session.user as any).branchId = (user as any).branchId ?? null;
        (session.user as any).role = (user as any).role ?? null;
      }
      return session;
    },
  },
  pages: {
    signIn: "/auth/signin",
  }
});

export { handler as GET, handler as POST };
