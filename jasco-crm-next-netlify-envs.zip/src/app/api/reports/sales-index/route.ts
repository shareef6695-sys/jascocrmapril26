import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import { withAuth } from "@/lib/handler";
import { assert, canViewCompany } from "@/lib/rbac";

export async function GET(req: NextRequest) {
  return withAuth(req, async ({ req, user }) => {
    const companyId = req.nextUrl.searchParams.get("companyId");
    assert(companyId && canViewCompany(user, companyId), "Forbidden");
    const leads = await prisma.lead.findMany({ where: { companyId } });
    const total = leads.filter(l=>l.stage!=="CLOSED_LOST").reduce((a,l)=>a+l.value,0);
    const won = leads.filter(l=>l.stage==="CLOSED_WON").reduce((a,l)=>a+l.value,0);
    const conv = leads.length ? Math.round(100*leads.filter(l=>l.stage==="CLOSED_WON").length / leads.length) : 0;
    return NextResponse.json({ total, won, conversionRate: conv });
  });
}
