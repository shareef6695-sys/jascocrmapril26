"use client";
import { signIn } from "next-auth/react";

export default function SignIn() {
  return (
    <main style={{maxWidth: 520, margin: '64px auto', padding: 24}}>
      <h1 style={{fontSize: 28, fontWeight: 700, marginBottom: 16}}>Sign in to JASCO CRM</h1>
      <p style={{opacity: .7, marginBottom: 24}}>Use your Google or Microsoft (Entra ID) account.</p>
      <div style={{display: 'grid', gap: 12}}>
        <button onClick={() => signIn('google')} style={{padding: '10px 14px', border: '1px solid #ddd', borderRadius: 10}}>Continue with Google</button>
        <button onClick={() => signIn('azure-ad')} style={{padding: '10px 14px', border: '1px solid #ddd', borderRadius: 10}}>Continue with Microsoft</button>
      </div>
    </main>
  );
}
