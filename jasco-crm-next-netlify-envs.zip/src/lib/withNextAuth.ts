import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import authConfig from "@/app/api/auth/[...nextauth]/route";

export async function withNextAuth(req: NextRequest, fn: (ctx: { req: NextRequest, user: any }) => Promise<Response>) {
  // @ts-ignore route.ts default export style
  const session = await getServerSession(authConfig.authOptions || (authConfig as any));
  if (!session?.user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  try {
    return await fn({ req, user: session.user });
  } catch (e: any) {
    const status = e?.status || 500;
    return NextResponse.json({ error: e.message || "Server error" }, { status });
  }
}
