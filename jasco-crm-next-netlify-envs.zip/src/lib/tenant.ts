import { NextRequest } from "next/server";

export function getTenant(req: NextRequest): { companyId?: string } {
  // Prefer X-Company-Id header for API calls from frontend
  const cid = req.headers.get("x-company-id") ?? undefined;
  return { companyId: cid };
}
