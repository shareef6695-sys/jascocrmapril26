import { prisma } from "@/lib/db";

export async function currentUser(token: string | null) {
  if (!token) return null;
  const session = await prisma.session.findFirst({ where: { token, expiresAt: { gt: new Date() } }, include: { user: true } });
  return session?.user ?? null;
}
