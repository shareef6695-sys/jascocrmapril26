import { Role } from "@prisma/client";

export function canViewCompany(user: any, companyId: string) {
  if (!user) return false;
  if (user.role === "SUPER_ADMIN") return true;
  return user.companyId === companyId;
}

export function canManageAdminCenter(user: any) {
  return user && (user.role === "SUPER_ADMIN" || user.role === "COMPANY_ADMIN");
}

export function assert(condition: any, msg = "Forbidden") {
  if (!condition) {
    const err = new Error(msg);
    (err as any).status = 403;
    throw err;
  }
}
