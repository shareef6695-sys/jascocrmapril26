import { NextRequest, NextResponse } from "next/server";
import { currentUser } from "./currentUser";

export async function withAuth(req: NextRequest, fn: (ctx: { req: NextRequest, user: any, token: string }) => Promise<Response>) {
  const auth = req.headers.get("authorization");
  const token = auth?.startsWith("Bearer ") ? auth.slice(7) : null;
  const user = await currentUser(token);
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  try {
    return await fn({ req, user, token: token! });
  } catch (e: any) {
    const status = e?.status || 500;
    return NextResponse.json({ error: e.message || "Server error" }, { status });
  }
}
