#!/usr/bin/env bash
set -e
echo "Running Prisma migrations..."
npx prisma migrate deploy
echo "Starting Next.js..."
node node_modules/next/dist/bin/next start -p 3000
