import { prisma } from "../src/lib/db";
import bcrypt from "bcryptjs";

async function main() {
  const steels = await prisma.company.upsert({
    where: { code: "2000" },
    update: {},
    create: { code: "2000", name: "JASCO STEELS" }
  });
  const pvc = await prisma.company.upsert({
    where: { code: "3000" },
    update: {},
    create: { code: "3000", name: "JASCO PVC" }
  });

  const [sJed, sRiy, sDam] = await Promise.all([
    prisma.branch.create({ data: { name: "STEELS - Jeddah", companyId: steels.id }}),
    prisma.branch.create({ data: { name: "STEELS - Riyadh", companyId: steels.id }}),
    prisma.branch.create({ data: { name: "STEELS - Dammam", companyId: steels.id }}),
  ]);
  const [pJed, pRiy, pDam] = await Promise.all([
    prisma.branch.create({ data: { name: "PVC - Jeddah", companyId: pvc.id }}),
    prisma.branch.create({ data: { name: "PVC - Riyadh", companyId: pvc.id }}),
    prisma.branch.create({ data: { name: "PVC - Dammam", companyId: pvc.id }}),
  ]);

  const pass = await bcrypt.hash("admin123", 10);

  const superAdmin = await prisma.user.upsert({
    where: { email: "sysadmin@jasco.local" },
    update: {},
    create: { name: "System Admin", email: "sysadmin@jasco.local", password: pass, role: "SUPER_ADMIN" }
  });

  const steelsAdmin = await prisma.user.upsert({
    where: { email: "admin.steels@jasco.local" },
    update: {},
    create: { name: "Steels Admin", email: "admin.steels@jasco.local", password: pass, role: "COMPANY_ADMIN", companyId: steels.id }
  });

  const pvcAdmin = await prisma.user.upsert({
    where: { email: "admin.pvc@jasco.local" },
    update: {},
    create: { name: "PVC Admin", email: "admin.pvc@jasco.local", password: pass, role: "COMPANY_ADMIN", companyId: pvc.id }
  });

  const srSteels = await prisma.user.upsert({
    where: { email: "sr.steels1@jasco.local" },
    update: {},
    create: { name: "Sales Steels 1", email: "sr.steels1@jasco.local", password: pass, role: "SALES_REP", companyId: steels.id, branchId: sJed.id }
  });

  await Promise.all([
    prisma.productGroup.create({ data: { name: "Steel Pipes", companyId: steels.id } }),
    prisma.productGroup.create({ data: { name: "Galvanized Tubes", companyId: steels.id } }),
    prisma.productGroup.create({ data: { name: "PVC Pipes", companyId: pvc.id } }),
    prisma.productGroup.create({ data: { name: "PVC Fittings", companyId: pvc.id } }),
  ]);

  console.log("Seeded successfully");
}

main().then(()=>process.exit(0)).catch(e=>{ console.error(e); process.exit(1); });
